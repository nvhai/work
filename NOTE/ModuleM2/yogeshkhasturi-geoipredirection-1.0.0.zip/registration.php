<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'YogeshKhasturi_GeoIpRedirection',
    __DIR__
);