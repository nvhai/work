<?php
/**
 * Created by PhpStorm.
 * User: doanhcn2
 * Date: 18/03/2019
 * Time: 11:17
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magenest_Feedback',
    __DIR__
);