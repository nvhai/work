<?php

namespace Eadesigndev\RomCity\Block\Checkout;

use Magento\Framework\View\Element\Template;

/**
 * Class CityUpdater
 * @package Eadesigndev\RomCity\Block\Checkout
 */
class CityUpdater extends Template
{

}
