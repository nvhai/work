# eacore
Core module for Magento 2 to add the menu for all the other modules.
