# ShipStation

Extract the zip file into magento root folder

then execute the setup upgrade command

php -f bin/magento setup:upgrade
