
var config = {
    map: {
        '*': {
            subscriptionsShippingFields: 'IWD_BluePaySubs/js/shippingFields'
        }
    }
};
