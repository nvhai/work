<?php
/**
 * Copyright © 2018 IWD Agency - All rights reserved.
 * See LICENSE.txt bundled with this module for license details.
 */
namespace IWD\BluePay\Block;

/**
 * Class Form
 */
class Form extends \Magento\Payment\Block\Adminhtml\Transparent\Form
{

}
