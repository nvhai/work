# Attachments

Attachments Extension for Magento 2.x

[GUIDE](https://github.com/SlavaYurthev/Attachments-M2/wiki)
