<?php
/**
 * Attachments
 * 
 * @author Slava Yurthev
 */
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'SY_Attachments',
	__DIR__
);