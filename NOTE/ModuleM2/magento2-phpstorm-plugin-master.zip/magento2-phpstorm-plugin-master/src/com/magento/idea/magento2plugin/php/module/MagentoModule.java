package com.magento.idea.magento2plugin.php.module;

/**
 * Created by dkvashnin on 12/5/15.
 */
public interface MagentoModule extends MagentoComponent {
    String getMagentoName();
}
