<?php

namespace Convert\RelatedToColour\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Catalog\Setup\CategorySetup;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Catalog\Model\ResourceModel\Product;

/**
 * Class ProductSetup
 *
 * @package Convert\RelatedToColour\Setup
 */
class ProductSetup extends EavSetup
{

    /**
     * @return array
     */
    public function getDefaultEntities()
    {
        return [
            'catalog_product' => [
                'entity_type_id' => CategorySetup::CATALOG_PRODUCT_ENTITY_TYPE_ID,
                'entity_model' => Product::class,
                'attribute_model' => Attribute::class,
                'table' => 'catalog_product_entity',
                'additional_attribute_table' => 'catalog_eav_attribute',
                'entity_attribute_collection' =>
                Collection::class,
                'attributes' => [
                    'colour_by_related' => [
                            'type' => 'int',
                            'label' => 'Colour Option By Related',
                            'input' => 'boolean',
                            'required' => false,
                            'sort_order' => '30',
                            'global' => ScopedAttributeInterface::SCOPE_GLOBAL,
                            'visible' => true,
                            'user_defined' => true,
                            'apply_to' => 'configurable',
                            'group' => 'General',
                    ],
                ]
            ]
        ];
    }
}
